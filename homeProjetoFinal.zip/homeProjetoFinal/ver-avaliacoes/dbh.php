<?php

$server = "localhost";
$username = "root";
$password = "root";
$dbname = "abmr";

$conn = mysqli_connect($server, $username, $password, $dbname);

mysqli_set_charset($conn,"utf8");




